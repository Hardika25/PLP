
export class Account{
    id:any;
    accHolder:any;
    mobile:any;
    balance:any;
   
}